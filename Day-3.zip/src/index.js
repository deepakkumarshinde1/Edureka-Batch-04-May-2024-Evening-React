import React from "react"; // node_module
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App.js"; // custom

const root = ReactDOM.createRoot(document.getElementById("edureka"));

root.render(
  <React.Fragment>
    <App />
  </React.Fragment>
);
