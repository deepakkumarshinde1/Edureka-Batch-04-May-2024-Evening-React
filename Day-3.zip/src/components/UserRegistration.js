import { useState } from "react";
import UserTable from "./UserTable";

const UserRegistration = () => {
  let [userInput, setUserInput] = useState({
    userName: "",
    userEmail: "",
  });

  let [userList, setUserList] = useState([]); // {},{},{}

  let inputChange = (event) => {
    let { name, value } = event.target;

    // create a new copy of userInput
    // spread operator ...
    let _userInput = { ...userInput }; // new copy

    _userInput[name] = value; // updated value
    setUserInput(_userInput); // updated state
  };

  let saveData = () => {
    // let _userList = [...userList]; //new copy
    // let _newUser = { ...userInput };
    // _userList.push(_newUser);
    // setUserList(_userList);

    // add a data in an array
    // push(data)
    // update state

    setUserList([...userList, { ...userInput }]);
    // reset input
    setUserInput({
      userName: "",
      userEmail: "",
    });
  };
  return (
    <>
      <section>
        <form>
          <div>
            <label htmlFor="">Name</label>
            <input
              value={userInput.userName}
              name="userName"
              type="text"
              placeholder="Enter Name"
              onChange={inputChange}
            />
          </div>
          <div>
            <label htmlFor="">Email</label>
            <input
              value={userInput.userEmail}
              name="userEmail"
              type="email"
              placeholder="Enter Email"
              onChange={inputChange}
            />
          </div>
          <div>
            <button type="button" onClick={saveData}>
              Save
            </button>
            <button type="reset">Reset</button>
          </div>
        </form>
      </section>
      <UserTable myList={userList} name="deepak" />
    </>
  );
};

export default UserRegistration;
