// import (optional)

import { useEffect, useState } from "react";

// component (function / class)
// function expression (arrow)
const App = () => {
  let [text, setText] = useState("Hello"); // [v, fn]
  let changeText = () => {
    setText("Edureka");
  };

  return (
    <>
      <button onClick={changeText}>Change Text</button>
      <h1 className="text-green">{text}</h1>
      <h1>TEXT {text}</h1>
      <input value={text} />
    </>
  );
};

// export
export default App;
