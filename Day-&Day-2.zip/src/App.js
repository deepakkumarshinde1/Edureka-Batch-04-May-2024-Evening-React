import UserRegistration from "./components/UserRegistration";

const App = () => {
  return (
    <>
      <UserRegistration />
    </>
  );
};

export default App;
