import { useState } from "react";
import UserRegistration from "./components/UserRegistration";
import UserTable from "./components/UserTable";
import { NavLink, Route, Routes, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";

const App = () => {
  // create a function Instance of useNavigate
  let navigate = useNavigate();
  let [userInput, setUserInput] = useState({
    userName: "",
    userEmail: "",
  });

  let [userList, setUserList] = useState([]); // {},{},{}

  let inputChange = (event) => {
    let { name, value } = event.target;

    // create a new copy of userInput
    // spread operator ...
    let _userInput = { ...userInput }; // new copy

    _userInput[name] = value; // updated value
    setUserInput(_userInput); // updated state
  };

  let saveData = () => {
    // let _userList = [...userList]; //new copy
    // let _newUser = { ...userInput };
    // _userList.push(_newUser);
    // setUserList(_userList);

    // add a data in an array
    // push(data)
    // update state

    setUserList([...userList, { ...userInput }]);
    // reset input
    setUserInput({
      userName: "",
      userEmail: "",
    });

    // message
    Swal.fire({
      title: "Success!",
      text: "User saved successfully",
      icon: "success",
      confirmButtonText: "Ok",
    }).then(() => {
      // navigate
      navigate("/user-list");
    });
  };

  return (
    <>
      <section className="container-fluid">
        <header className="row">
          <nav className="col-12 border-bottom shadow-sm py-2">
            <ul className="list-unstyled d-flex gap-4 justify-content-center mb-0">
              <li>
                <NavLink
                  to="/"
                  className={({ isActive }) =>
                    isActive
                      ? "text-success text-decoration-none"
                      : "text-decoration-none"
                  }
                >
                  <i className="fa fa-home" aria-hidden="true"></i> Home
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/user-list"
                  className={({ isActive }) =>
                    isActive
                      ? "text-success text-decoration-none"
                      : "text-decoration-none"
                  }
                >
                  <i className="fa fa-users" aria-hidden="true"></i> User List
                </NavLink>
              </li>
            </ul>
          </nav>
        </header>
        <Routes>
          <Route
            path="/"
            element={
              <UserRegistration
                inputChange={inputChange}
                userInput={userInput}
                saveData={saveData}
              />
            }
          />
          <Route path="/user-list" element={<UserTable myList={userList} />} />
        </Routes>
      </section>
    </>
  );
};

export default App;
