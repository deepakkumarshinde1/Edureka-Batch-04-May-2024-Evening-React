import Input from "./Input";

const UserRegistration = (props) => {
  let { inputChange, userInput, saveData } = props;
  return (
    <>
      <section className="row justify-content-center">
        <section className="col-6 card mt-3 p-3">
          <form>
            <Input
              label="User Name"
              userInput={userInput}
              name="userName"
              placeholder="Enter User Name"
              inputChange={inputChange}
              type="text"
            />

            <Input
              label="User Email"
              userInput={userInput}
              name="userEmail"
              placeholder="Enter Email"
              inputChange={inputChange}
              type="email"
            />

            <div className="justify-content-center gap-3 d-flex">
              <button
                type="button"
                onClick={saveData}
                className="btn btn-success px-5 rounded-0"
              >
                <i className="fa fa-floppy-o" aria-hidden="true"></i> Save
              </button>
              <button type="reset" className="btn btn-outline-danger rounded-0">
                <i className="fa fa-history" aria-hidden="true"></i> Reset
              </button>
            </div>
          </form>
        </section>
      </section>
    </>
  );
};

export default UserRegistration;
