const Input = (props) => {
  let { label, userInput, name, placeholder, inputChange, type } = props;
  return (
    <>
      <div className="mb-2">
        <label htmlFor={name} className="form-label">
          {label}
        </label>
        <input
          value={userInput.userName}
          name={name}
          type={type}
          id={name}
          placeholder={placeholder}
          onChange={inputChange}
          className="form-control"
        />
      </div>
    </>
  );
};

export default Input;
