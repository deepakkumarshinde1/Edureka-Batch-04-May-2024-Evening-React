import Input from "./Input";
import { useCallback, useEffect } from "react";
import ResetButton from "./ResetButton";
import { useUserContext } from "../context/user.context";

const UserRegistration = () => {
  let { userInput, inputChange, saveUserData, resetInput, dispatch, error } =
    useUserContext();

  useEffect(() => {
    // unmounting
    return () => {
      dispatch(resetInput());
    };
  }, []); // mounting

  return (
    <>
      <section className="row justify-content-center">
        <section className="col-6 card mt-3 p-3">
          <form>
            <Input
              label="User Name"
              name="userName"
              placeholder="Enter User Name"
              type="text"
              inputChange={useCallback(inputChange, [userInput.userName])}
              value={userInput.userName}
              error={error}
            />

            <Input
              label="User Email"
              value={userInput.userEmail}
              name="userEmail"
              placeholder="Enter Email"
              inputChange={useCallback(inputChange, [userInput.userEmail])}
              type="email"
              error={error}
            />

            <div className="justify-content-center gap-3 d-flex">
              <button
                type="button"
                onClick={saveUserData}
                className="btn btn-success px-5 rounded-0"
              >
                <i className="fa fa-floppy-o" aria-hidden="true"></i> Save
              </button>
              <ResetButton />
            </div>
          </form>
        </section>
      </section>
    </>
  );
};

export default UserRegistration;
