import { createContext, useContext, useReducer, useState } from "react";

import {
  getUserListService,
  removeUserService,
  saveUserDataService,
} from "./user.service";
import { initialState, reducer, userFormSchema } from "./user.reducer";
import {
  handelError,
  onInputChange,
  resetInput,
  setFormErrors,
  updateUserListFormServer,
  userAddedToServer,
  userRemoveSuccessMessage,
} from "./user.actions";

// context
let UserContext = createContext({});

// context.provider ==> Component
export let UserContextProvider = (props) => {
  let { children } = props;

  let [state, dispatch] = useReducer(reducer, initialState);

  let inputChange = (event) => {
    let { name, value } = event.target;
    let data = {
      name,
      value,
    };
    dispatch(onInputChange(data));
  };

  let saveUserData = async () => {
    try {
      // validation
      await userFormSchema.validate(state.userInput, { abortEarly: false });
      await saveUserDataService(state.userInput);
      dispatch(userAddedToServer(true));
      dispatch(setFormErrors({}));
    } catch (error) {
      let _error = {};
      error.inner.forEach((value, index) => {
        if (_error[value.path] === undefined) {
          _error[value.path] = value.message;
        }
      });
      dispatch(setFormErrors(_error));
    }
  };

  let getUserListFormServer = async () => {
    try {
      let { data } = await getUserListService();
      dispatch(updateUserListFormServer(data));
    } catch (error) {
      dispatch(handelError(error.message));
    }
  };

  let callRemoveUserService = async (id) => {
    try {
      await removeUserService(id);
      dispatch(userRemoveSuccessMessage(true));
    } catch (error) {
      dispatch(handelError(error.message));
    }
  };

  let values = {
    ...state,
    saveUserData,
    inputChange,
    callRemoveUserService,
    getUserListFormServer,
    userAddedToServer,
    userRemoveSuccessMessage,
    resetInput,
    setErrorMessage: handelError,
    dispatch,
  };

  return <UserContext.Provider value={values}>{children}</UserContext.Provider>;
};

// custom hook
export const useUserContext = () => {
  return useContext(UserContext);
};
