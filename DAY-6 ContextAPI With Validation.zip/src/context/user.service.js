import axios from "axios";

export async function saveUserDataService(userInput) {
  let id = Date.now();
  let url = `http://localhost:3004/user`;
  return await axios.post(url, { ...userInput, id });
}

export async function getUserListService() {
  let url = `http://localhost:3004/user`;
  return await axios.get(url);
}

export async function removeUserService(id) {
  let url = `http://localhost:3004/user/${id}`;
  return await axios.delete(url);
}
