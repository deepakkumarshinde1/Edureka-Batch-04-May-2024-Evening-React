import { createSlice } from "@reduxjs/toolkit";

const UserSlice = createSlice({
  name: "UserSlice",
  initialState: {
    userInput: {
      userName: "",
      userEmail: "",
    },
    userList: [],
  },
  reducers: {
    onInputChange(state, action) {
      // action ==> { type , payload }
      let { name, value } = action.payload;
      state.userInput[name] = value;
    },

    resetInput(state) {
      state.userInput = {
        userName: "",
        userEmail: "",
      };
    },

    saveUserList(state, action) {
      state.userList = action.payload;
    },
  },
});

export default UserSlice;
export const { resetInput, onInputChange, saveUserList } = UserSlice.actions;
