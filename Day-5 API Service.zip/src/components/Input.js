const Input = (props) => {
  let { label, value, name, placeholder, inputChange, type } = props;
  return (
    <>
      <div className="mb-2">
        <label htmlFor={name} className="form-label">
          {label}
        </label>
        <input
          value={value}
          name={name}
          type={type}
          id={name}
          placeholder={placeholder}
          onChange={inputChange}
          className="form-control"
        />
      </div>
    </>
  );
};

export default Input;
