import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { saveUserList } from "../redux/user.slice";
import axios from "axios";
import Swal from "sweetalert2";

const UserTable = () => {
  let dispatch = useDispatch();
  let { userList } = useSelector((state) => state.users);

  // let [userList , setUserList] = useState([])

  let getUserList = async () => {
    let url = `http://localhost:3004/user`;
    let response = await fetch(url);
    let data = await response.json();
    dispatch(saveUserList(data));
    // setUserList(data)
  };

  // on page load
  useEffect(() => {
    getUserList();
  }, []); // only once

  let removeUser = async (id) => {
    try {
      let url = `http://localhost:3004/user/${id}`;
      await axios.delete(url);

      Swal.fire({
        title: "Success!",
        text: "User removed successfully",
        icon: "success",
        confirmButtonText: "Ok",
      }).then(() => {
        getUserList();
      });
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message,
        icon: "error",
        confirmButtonText: "Ok",
      });
    }
  };
  return (
    <>
      <section className="row mt-3  justify-content-center">
        <section className="col-8 ">
          <table className="table table-bordered">
            <thead className="table-primary text-center">
              <tr>
                <th width="10%">Sr No</th>
                <th width="40%">Name</th>
                <th width="40%">Email</th>
                <th width="10%">Action</th>
              </tr>
            </thead>
            <tbody>
              {userList.length === 0 ? (
                <tr>
                  <td colSpan={3} className="text-center fw-bold text-danger">
                    No data to display
                  </td>
                </tr>
              ) : null}
              {userList.map((user, index) => {
                return (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{user.userName}</td>
                    <td>{user.userEmail}</td>
                    <td>
                      <button
                        onClick={() => removeUser(user.id)}
                        className="btn btn-outline-danger btn-sm"
                      >
                        <i className="fa fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </section>
      </section>
    </>
  );
};

export default UserTable;
