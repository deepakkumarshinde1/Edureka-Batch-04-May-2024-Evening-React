export function onInputChange(payload) {
  return { type: "INPUT_CHANGE", payload };
}

export function resetInput() {
  return { type: "RESET_INPUT" };
}

export function updateUserListFormServer(data) {
  return { type: "UPDATE_USER_LIST", payload: data };
}

export function userRemoveSuccessMessage(payload) {
  return { type: "SHOW_REMOVE_USER_MESSAGE", payload };
}

export function userAddedToServer(payload) {
  return { type: "USER_SAVE_SUCCESS", payload };
}

export function handelError(payload) {
  return { type: "HANDEL_ERROR", payload };
}
