import * as yup from "yup";

export const userFormSchema = yup.object().shape({
  userName: yup.string().min(2, "Invalid Name").required("Enter User Name"),
  userEmail: yup.string().email("Invalid Email").required("Enter Email"),
});
export const initialState = {
  removeUserMessage: false,
  errorMessage: null,
  userSaveDone: false,
  userInput: {
    userName: "",
    userEmail: "",
  },
  userList: [],
};

export const reducer = (state, action) => {
  let { payload, type } = action;
  switch (type) {
    case "INPUT_CHANGE":
      let _userInput = state.userInput;
      let { name, value } = payload;
      _userInput[name] = value;
      return { ...state, userInput: _userInput };

    case "USER_SAVE_SUCCESS":
      return { ...state, userSaveDone: payload };

    case "UPDATE_USER_LIST":
      return { ...state, userList: [...payload] };

    case "RESET_INPUT":
      return {
        ...state,
        userInput: {
          userName: "",
          userEmail: "",
        },
      };

    case "SHOW_REMOVE_USER_MESSAGE":
      return { ...state, removeUserMessage: payload };

    case "HANDEL_ERROR":
      return { ...state, errorMessage: payload };
    default:
      return state;
  }
};
