import { useContext, useEffect, useState } from "react";
import Swal from "sweetalert2";
import { useUserContext } from "../context/user.context";

const UserTable = () => {
  let { userList, getUserListFormServer, callRemoveUserService, dispatch } =
    useUserContext();

  useEffect(() => {
    getUserListFormServer();
  }, []); // only once

  let removeUser = async (id) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        callRemoveUserService(id);
      }
    });
  };

  return (
    <>
      <section className="row mt-3  justify-content-center">
        <section className="col-8 ">
          <table className="table table-bordered">
            <thead className="table-primary text-center">
              <tr>
                <th width="10%">Sr No</th>
                <th width="40%">Name</th>
                <th width="40%">Email</th>
                <th width="10%">Action</th>
              </tr>
            </thead>
            <tbody>
              {userList.length === 0 ? (
                <tr>
                  <td colSpan={3} className="text-center fw-bold text-danger">
                    No data to display
                  </td>
                </tr>
              ) : null}
              {userList.map((user, index) => {
                return (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{user.userName}</td>
                    <td>{user.userEmail}</td>
                    <td>
                      <button
                        onClick={() => removeUser(user.id)}
                        className="btn btn-outline-danger btn-sm"
                      >
                        <i className="fa fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </section>
      </section>
    </>
  );
};

export default UserTable;
