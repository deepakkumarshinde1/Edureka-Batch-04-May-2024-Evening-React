import { useDispatch, useSelector } from "react-redux";
import Input from "./Input";
import { onInputChange, saveUser } from "../redux/user.slice";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";

const UserRegistration = () => {
  let dispatch = useDispatch();
  let navigate = useNavigate();
  let { userInput } = useSelector((state) => state.users);

  let inputChange = (event) => {
    let { name, value } = event.target;
    let data = {
      name,
      value,
    };
    dispatch(onInputChange(data));
  };

  let saveUserData = () => {
    dispatch(saveUser());

    Swal.fire({
      title: "Success!",
      text: "User saved successfully",
      icon: "success",
      confirmButtonText: "Ok",
    }).then(() => {
      // navigate
      navigate("/user-list");
    });
  };
  return (
    <>
      <section className="row justify-content-center">
        <section className="col-6 card mt-3 p-3">
          <form>
            <Input
              label="User Name"
              name="userName"
              placeholder="Enter User Name"
              type="text"
              inputChange={inputChange}
              value={userInput.userName}
            />

            <Input
              label="User Email"
              value={userInput.userEmail}
              name="userEmail"
              placeholder="Enter Email"
              inputChange={inputChange}
              type="email"
            />

            <div className="justify-content-center gap-3 d-flex">
              <button
                type="button"
                onClick={saveUserData}
                className="btn btn-success px-5 rounded-0"
              >
                <i className="fa fa-floppy-o" aria-hidden="true"></i> Save
              </button>
              <button type="reset" className="btn btn-outline-danger rounded-0">
                <i className="fa fa-history" aria-hidden="true"></i> Reset
              </button>
            </div>
          </form>
        </section>
      </section>
    </>
  );
};

export default UserRegistration;
