import { createSlice } from "@reduxjs/toolkit";

const UserSlice = createSlice({
  name: "UserSlice",
  initialState: {
    userInput: {
      userName: "",
      userEmail: "",
    },
    userList: [],
  },
  reducers: {
    onInputChange(state, action) {
      // action ==> { type , payload }
      let { name, value } = action.payload;
      state.userInput[name] = value;
    },
    saveUser(state) {
      state.userList.push({ ...state.userInput });
      state.userInput = {
        userName: "",
        userEmail: "",
      };
    },
  },
});

export default UserSlice;
export const { onInputChange, saveUser } = UserSlice.actions;
