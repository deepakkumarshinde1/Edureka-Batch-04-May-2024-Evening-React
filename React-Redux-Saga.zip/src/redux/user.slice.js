import { createSlice } from "@reduxjs/toolkit";

const UserSlice = createSlice({
  name: "UserSlice",
  initialState: {
    removeUserMessage: false,
    errorMessage: null,
    userSaveDone: false,
    userInput: {
      userName: "",
      userEmail: "",
    },
    userList: [],
  },
  reducers: {
    onInputChange(state, action) {
      // action ==> { type , payload }
      let { name, value } = action.payload;
      state.userInput[name] = value;
    },

    resetInput(state) {
      state.userInput = {
        userName: "",
        userEmail: "",
      };
    },

    saveUserList(state, action) {
      state.userList = action.payload;
    },

    setErrorMessage(state, action) {
      state.errorMessage = action.payload;
    },
    sendUserDetails() {},
    getUserListFormServer() {},
    callRemoveUserService() {},
    userAddedToServer(state, action) {
      state.userSaveDone = action.payload;
    },
    userRemoveSuccessMessage(state, action) {
      state.removeUserMessage = action.payload;
    },
  },
});

export default UserSlice;
export const {
  callRemoveUserService,
  userRemoveSuccessMessage,
  setErrorMessage,
  getUserListFormServer,
  userAddedToServer,
  sendUserDetails,
  resetInput,
  onInputChange,
  saveUserList,
} = UserSlice.actions;
