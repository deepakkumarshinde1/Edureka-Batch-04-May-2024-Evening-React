import { call, put } from "redux-saga/effects";
import {
  getUserListService,
  removeUserService,
  saveUserDataService,
} from "./user.service";
import {
  saveUserList,
  setErrorMessage,
  userAddedToServer,
  userRemoveSuccessMessage,
} from "../user.slice";

export function* saveUserDataHandler(action) {
  try {
    let userInput = action.payload;
    yield call(saveUserDataService, userInput);
    yield put(userAddedToServer(true));
  } catch (error) {
    yield put(setErrorMessage(error.message));
  }
}

export function* getUserListHandler() {
  try {
    let { data } = yield call(getUserListService);
    yield put(saveUserList(data));
  } catch (error) {
    yield put(setErrorMessage(error.message));
  }
}

export function* removeUserHandler(action) {
  try {
    let id = action.payload;
    yield call(removeUserService, id);
    yield put(userRemoveSuccessMessage(true));
  } catch (error) {
    yield put(setErrorMessage(error.message));
  }
}
