import { takeLatest } from "redux-saga/effects";
import {
  getUserListHandler,
  removeUserHandler,
  saveUserDataHandler,
} from "./user.handler";
import {
  callRemoveUserService,
  getUserListFormServer,
  sendUserDetails,
} from "../user.slice";

export function* saveUserDataWatcher() {
  yield takeLatest(sendUserDetails.type, saveUserDataHandler);
}

export function* getUserListWatcher() {
  yield takeLatest(getUserListFormServer.type, getUserListHandler);
}

export function* removeUserWatcher() {
  yield takeLatest(callRemoveUserService.type, removeUserHandler);
}
