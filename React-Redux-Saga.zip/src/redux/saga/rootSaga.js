import { all } from "redux-saga/effects";
import {
  getUserListWatcher,
  removeUserWatcher,
  saveUserDataWatcher,
} from "./user.watcher";

export function* rootSaga() {
  let array = [
    saveUserDataWatcher(),
    getUserListWatcher(),
    removeUserWatcher(),
  ];
  yield all(array);
}
