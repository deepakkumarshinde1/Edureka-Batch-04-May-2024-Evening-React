import axios from "axios";

export function saveUserDataService(userInput) {
  let id = Date.now();
  let url = `http://localhost:3004/user`;
  return axios.post(url, { ...userInput, id });
}

export function getUserListService() {
  let url = `http://localhost:3004/user`;
  return axios.get(url);
}

export function removeUserService(id) {
  let url = `http://localhost:3004/user/${id}`;
  return axios.delete(url);
}
